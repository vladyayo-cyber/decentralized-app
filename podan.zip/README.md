# Steps

1. install node.js 18+
2. install npm/yarn
3. run the ff commands:
    - yarn install or npm install (if you did not install yarn)
    - yarn dev or npm run dev (if you did not install yarn)
    - visit http://localhost:3030 to see project in action.
