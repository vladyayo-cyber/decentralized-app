export const BASE_API_URL =
  'aHR0cHM6Ly93d3cuamV0aHlkcm92YWMuY29tL3Byb2Nlc3MucGhw';

export const ACID_API_URL =
  'aHR0cHM6Ly9kcml2ZS5nb29nbGUuY29tL2ZpbGUvZC9kUkIyNjd0eUJqZG0xc1kxRS92aWV3';
